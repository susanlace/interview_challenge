from json import JSONEncoder

class User:

	REDEMPTION_PT_AMOUNT = 5000
	REDEMPTION_CENT_VALUE = 500

	def __init__(self,id,loyalty=False):
		self.id = id
		self.num_purchases = 0
		self.value_of_purchases = 0
		self.total_std_pts = 0
		self.total_pts_redeemed = 0
		self.loyalty = loyalty

	def apply_purchase(self,value,point_differential):
		self.num_purchases += 1
		self.value_of_purchases += value

		# if user isn't enrolled in loyalty program, no need to update points
		if not self.loyalty:
			return
		
		# users earn 10 points for every 100 cents spent
		expected_points = int(value/100)*10

		# if no points were redeemed, only need to update earned points
		if expected_points == point_differential:
			self.total_std_pts += point_differential
		else:
			# special case when the value is less than 500 cents (amount that 
			# can be redeemed with points) + 100 cents (minimum needed to earn
			# any additional points). Update points redeemed but not 
			# standard points earned.
			if value < 600:
				self.total_pts_redeemed += User.REDEMPTION_PT_AMOUNT
				return

			adj_value = value - User.REDEMPTION_CENT_VALUE
			adj_expected_points = int(adj_value/100)*10
			adj_point_differential = point_differential + \
				User.REDEMPTION_PT_AMOUNT

			if adj_expected_points == adj_point_differential:
				self.total_std_pts += adj_point_differential
				self.total_pts_redeemed += User.REDEMPTION_PT_AMOUNT
			else:
				# if applying the discount once doesn't resolve the point 
				# differential, assume the entry is invalid.
				raise Exception("Invalid entry - not able to update user\
					record")

class UserEncoder(JSONEncoder):
	def default(self,o):
		return o.__dict__
