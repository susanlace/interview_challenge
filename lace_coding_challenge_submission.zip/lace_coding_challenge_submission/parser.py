import requests
import json
from user import User,UserEncoder

OUTFILE_PATH = 'results.json'

user_text = requests.get(\
		'https://button-ie-coding-challenge.herokuapp.com/users').text
transaction_text = requests.get(\
		'https://button-ie-coding-challenge.herokuapp.com/transactions').text

# strip out the extra text surrounding the json objects
user_text = user_text[9:-1]
transaction_text = transaction_text[16:-1]

user_data = json.loads(user_text)
transaction_data = json.loads(transaction_text)

# build a dictionary of User objects so that we can later have O(1) lookup time
# when applying transactions
user_dict = {}
for user_entry in user_data:
	user_id = int(user_entry['id'])
	user_loyalty = (user_entry['loyalty'] == 'enrolled')
	user_dict[user_id] = User(user_id,user_loyalty)

# loop through the transactions and update Users' data accordingly
for transaction in transaction_data:
	transaction_user = user_dict[int(transaction['user_id'])]
	transaction_user.apply_purchase(int(transaction['value']),\
		int(transaction['point_differential']))

with open(OUTFILE_PATH,mode='w') as out_file:
	json.dump(list(user_dict.values()),out_file,cls=UserEncoder)





